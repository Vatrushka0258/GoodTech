<?php
$host = 'localhost'; 
$user = 'root'; 
$password = ''; 
$database = 'wordpress'; // Используем вашу БД

// Подключение к базе данных
$conn = new mysqli($host, $user, $password, $database);
if ($conn->connect_error) {
    die("Ошибка подключения: " . $conn->connect_error);
}

// Подготовка SQL-запроса
$stmt = $conn->prepare("INSERT INTO Orders 
    (NomerTovara, IdBranch, LastNameCustomer, FirstNameCustomer, PatronymicCustomer, Telephone, Gorod, Adres, Volume, Weight, TotalCost, PaymentMethod) 
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

// Привязка данных из формы
$stmt->bind_param("iissssssddis", 
    $_POST['NomerTovara'], 
    $_POST['IdBranch'], 
    $_POST['LastNameCustomer'], 
    $_POST['FirstNameCustomer'], 
    $_POST['PatronymicCustomer'], 
    $_POST['Telephone'], 
    $_POST['Gorod'], 
    $_POST['Adres'], 
    $_POST['Volume'], 
    $_POST['Weight'], 
    $_POST['TotalCost'], 
    $_POST['PaymentMethod']
);

// Выполнение запроса и вывод результата
if ($stmt->execute()) {
    echo "Заказ успешно создан!";
} else {
    echo "Ошибка: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
